#include <stdio.h>
#include <pthread.h>


/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "semphr.h"

/* Priorities at which the tasks are created. */

#define TASK1_PRIORITY  ( tskIDLE_PRIORITY + 4 )
#define TASK2_PRIORITY  ( tskIDLE_PRIORITY + 1 )
#define TASK3_PRIORITY  ( tskIDLE_PRIORITY + 2 )
#define TASK4_PRIORITY  ( tskIDLE_PRIORITY + 3 )

/* The rate at which data is sent to the queue. The times are converted from
 * milliseconds to ticks using the pdMS_TO_TICKS() macro. */

#define MAIN_TASK_1 pdMS_TO_TICKS(8000UL)
#define MAIN_TASK_2 pdMS_TO_TICKS(2000UL)
#define MAIN_TASK_3 pdMS_TO_TICKS(4000UL)
#define MAIN_TASK_4 pdMS_TO_TICKS(6000UL)

/*-----------------------------------------------------------*/

/*
 * The tasks as described in the comments at the top of this file.
 */

static void Task_1(void *pvParameters);
static void Task_2(void *pvParameters);
static void Task_3(void *pvParameters);
static void Task_4(void *pvParameters);

/*** SEE THE COMMENTS AT THE TOP OF THIS FILE ***/
void ipsa_sketch(void) {
    TaskHandle_t task1_handle = NULL;
    TaskHandle_t task2_handle = NULL;
    TaskHandle_t task3_handle = NULL;
    TaskHandle_t task4_handle = NULL;

    /* Start the four tasks as described in the comments at the top of this
     * file. */
    vTaskCreate(Task_1, "Task_1", configMINIMAL_STACK_SIZE, NULL, TASK1_PRIORITY, &task1_handle);
    vTaskCreate(Task_2, "Task_2", configMINIMAL_STACK_SIZE, NULL, TASK2_PRIORITY, &task2_handle);
    vTaskCreate(Task_3, "Task_3", configMINIMAL_STACK_SIZE, NULL, TASK3_PRIORITY, &task3_handle);
    vTaskCreate(Task_4, "Task_4", configMINIMAL_STACK_SIZE, NULL, TASK4_PRIORITY, &task4_handle);

    /* Start the tasks and timer running. */
    vTaskStartScheduler();
}

static void Task_1(void *pvParameters) {
    (void)pvParameters;
    while (1) {
        printf("Working\n");
        vTaskDelay(MAIN_TASK_1);
    }
}

static void Task_2(void *pvParameters) {
    const int fahrenheit = 68;
    int celsius;
    (void)pvParameters;
    while (1) {
        celsius = (5 * (fahrenheit - 32)) / 9;
        vTaskDelay(MAIN_TASK_2);
    }
}

static void Task_3(void *pvParameters) {
    long int num1 = 1234567890L;
    long int num2 = 9876543210L;
    long int result;
    (void)pvParameters;
    while (1) {
        result = num1 * num2;
        vTaskDelay(MAIN_TASK_3);
    }
}

static int binarySearch(int arr[], int l, int r, int x) {
    while (l <= r) {
        int m = l + (r - l) / 2;
        if (arr[m] == x)
            return m;
        if (arr[m] < x)
            l = m + 1;
        else
            r = m - 1;
    }
    return -1;
}

static void Task_4(void *pvParameters) {
    int data[50];
    for (int i = 0; i < 50; i++) {
        data[i] = i * 2;
    }
    int target = 36;
    (void)pvParameters;
    while (1) {
        int result = binarySearch(data, 0, 49, target);
        vTaskDelay(MAIN_TASK_4);
    }
}


